/**
 * @file nxpcup_start.h
 *
 *
 * @author Katrin Moritz
 */
#ifndef NXPCUP_START_
#define NXPCUP_START_

#include <px4_platform_common/px4_config.h>
#include <px4_platform_common/log.h>
#include <px4_platform_common/app.h>
#include <px4_platform_common/init.h>
#include <px4_platform_common/tasks.h>
#include <px4_platform_common/posix.h>

#include <stdio.h>
#include <string.h>
#include <sched.h>
#include <lib/matrix/matrix/Euler.hpp>
#include <lib/matrix/matrix/Quaternion.hpp>

#include <uORB/Subscription.hpp>
#include <uORB/Publication.hpp>
#include <uORB/uORB.h>
#include <uORB/topics/vehicle_control_mode.h>
#include <uORB/topics/vehicle_attitude_setpoint.h>
#include <uORB/topics/safety.h>

#endif /*NXPCUP_START_*/

