/**
 * @file hello_example.h
 * Race code for NXP Cup
 *
 * @author Katrin Moritz
 */
#ifndef NXPCUP_RACE_
#define NXPCUP_RACE_

#include <px4_defines.h>

#include "Pixy2I2C_PX4.h"

struct roverControl {
	float steer;
	float speed;
};

struct _vector {
	float x;
	float y;
	float norm;
	float grad;
};

roverControl raceTrack(Pixy2 &pixy);

#endif
