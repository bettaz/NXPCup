/**
 * @file hello_example.cpp
 * Race code for NXP Cup
 *
 * @author Katrin Moritz
 */

#include "nxpcup_race.h"

#include <stdio.h>
#include <string.h>
#include <math.h>


roverControl raceTrack(Pixy2 &pixy)
{
	roverControl control{};
	/* instert you algorithm here */
	PX4_INFO("Alessio Breakpoint");
	// test values for speed and steering
	control.steer = 0.2f;
	control.speed = 0.1f;


	return control;
}
